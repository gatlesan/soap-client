import client.SoapClient;

public class Main {

    public static void main(String[] args) {

        SoapClient soapClient = new SoapClient();
        soapClient.getTrackerInfo();

    }
}
