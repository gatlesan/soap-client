package client;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;

public class SoapClient {

    private WebServiceTemplate template;

    public void getTrackerInfo() {
        Object request = new Object();
        template = new WebServiceTemplate();
        System.out.println(template);
//        Object response = template.marshalSendAndReceive("http://localhost:8080/ws",
//                request);

    }
}
